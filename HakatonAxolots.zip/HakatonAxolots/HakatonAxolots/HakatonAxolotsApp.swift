//
//  HakatonAxolotsApp.swift
//  HakatonAxolots
//
//  Created by ADMIN UNACH on 02/03/24.
//

import SwiftUI

@main
struct HakatonAxolotsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
