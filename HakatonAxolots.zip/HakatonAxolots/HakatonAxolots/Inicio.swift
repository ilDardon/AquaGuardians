//
//  Inicio.swift
//  HakatonAxolots
//
//  Created by ADMIN UNACH on 02/03/24.
//

import SwiftUI

struct Inicio: View {

    @State private var isActiveMenu = false
   
    var body: some View {
        
        ZStack {
            
            Spacer()
            
            Image("Rio-3")
                .resizable()
                .frame(width: 1229, height: 1028)
            
            VStack{
                
                Text("Nombre App")
                    .foregroundColor(.black)
                    .font(Font.custom("Arial Rounded MT Bold", size: 40))
                    .offset(y: 200)
                
                Image("Ajolote")
                    .resizable()
                    .frame(width: 287, height: 398)
                    .shadow(radius: 15)
                    .offset(x:10, y: 350)
                    .animateVertically(endPosition: 30.0, duration: 1)
                
                Button(action: {
                    isActiveMenu.toggle()
                }){
                    RoundedRectangle(cornerRadius: 50)
                        .shadow(color: .black, radius: 8, x: 5, y: 5)
                        .frame(width: 180, height: 60)
                        .foregroundColor(Color.orange)
                        .overlay(
                            Text("INICIAR")
                                .foregroundColor(.white)
                                .font(Font.custom("Arial Rounded MT Bold", size: 30))
                        )
                }
                .offset(x: 460, y: 347)
                .fullScreenCover(isPresented: $isActiveMenu){
                    Menu()
                }
                
                Spacer()
            }
        }
    }
}

#Preview {
    Inicio()
}
