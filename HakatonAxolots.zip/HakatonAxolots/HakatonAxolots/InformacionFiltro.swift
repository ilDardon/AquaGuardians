//
//  InformacionFIltro.swift
//  HakatonAxolots
//
//  Created by ADMIN UNACH on 06/03/24.
//

import SwiftUI

struct InformacionFiltro: View {
    
    @State private var isImage1Visible = false
    @State private var isImage2Visible = false
    @State private var isImage3Visible = false
    
    var body: some View {
        
        ZStack {
            
            LinearGradient(
                gradient: Gradient(colors: [Color.blue, Color.green]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            
            if isImage1Visible {
                Text("Aprendiendo Sobre Filtros")
                    .foregroundColor(.white)
                    .offset(x: 0.0, y: -250)
                
                HStack{
                    
                    if isImage2Visible {
                        Image("Ajolote_Lentes")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 400)
                            .offset(x: 0.0, y: -30)
                            .animateVertically(endPosition: 30.0, duration: 1.0)
                    }
                    
                    if isImage3Visible{
                        Images(images: ["imagen1", "imagen2", "imagen3"])
                            .frame(width: 300, height: 300)
                    }
                }
                
                
                Text("Existen diferentes usos para cada filtro")
                    .foregroundColor(.white)
                    .offset(x: 0.0, y: 250)
            }
        }
        .onAppear {
            // Puedes agregar algún retraso (con DispatchQueue) si quieres un intervalo de tiempo entre cada imagen
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                withAnimation {
                    isImage1Visible = true
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                withAnimation {
                    isImage2Visible = true
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                withAnimation {
                    isImage3Visible = true
                }
            }
        }

    }
    
}

#Preview {
    InformacionFiltro()
}
