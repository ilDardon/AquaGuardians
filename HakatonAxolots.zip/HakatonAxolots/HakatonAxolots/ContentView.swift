//
//  ContentView.swift
//  HakatonAxolots
//
//  Created by ADMIN UNACH on 02/03/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Inicio()
    }
}

#Preview {
    ContentView()
}
