//
//  Menu.swift
//  HakatonAxolots
//
//  Created by ADMIN UNACH on 02/03/24.
//

import SwiftUI

struct Menu: View {

    @State private var showModal = false
    @State private var isActiveInicio = false
    
    var body: some View {
        
        ZStack{
            
            Image("Mapa_Flotante")
                .resizable()
                .frame(width: 1190, height: 850, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            
            VStack(spacing: 50){
                
                Button(action: {}){

                    Image("Casitas")
                        .resizable()
                        .frame(width: 180, height: 150)
                        .animateVertically(endPosition: -20, duration: 1)
                        .shadow(color: Color.white, radius: 5)

                }
                .offset(x: -215)
                .offset(y: 90)
                
                //Prueba
                Button(action: {}){

                    Image("Casa_Flotante")
                        .resizable()
                        .frame(width: 100, height: 150)
                        .animateVertically(endPosition: -20.0, duration: 1)
                        .shadow(color: Color.white, radius: 5)

                }
                .offset(x: -480)
                .offset(y: 250)

                Button(action: {}){

                    Image("Huerto")
                        .resizable()
                        .frame(width: 200, height: 150)
                        .animateVertically(endPosition: -20.0, duration: 1)
                        .shadow(color: Color.white, radius: 5)

                }
                .offset(x: 160)
                .offset(y: -180)
                
                HStack{
                    //Boton de retorno a la pantalla de inicio
                    Button(action: {
                        isActiveInicio.toggle()
                    }){
                        RoundedRectangle(cornerRadius: 100)
                            .shadow(color: .gray, radius: 4, x: 4, y: 4)
                            .frame(width: 80, height: 80)
                            .foregroundColor(Color.green)
                            .overlay(
                                
                                Image(systemName: "rectangle.portrait.and.arrow.right")
                                    .resizable()
                                    .frame(width: 40, height: 40)
                                    .rotationEffect(.degrees(180))

                                    .offset(x: -5)
                                    .foregroundColor(.white)
                                
                            )
                        
                    }
                    .fullScreenCover(isPresented: $isActiveInicio){
                        Inicio()
                    }
                    .offset(x: 210.0)
                    
                    //Como jugar
                    Button(action: {
//                        isActiveInicio.toggle()
                    }){
                        RoundedRectangle(cornerRadius: 100)
                            .shadow(color: .gray, radius: 4, x: 4, y: 4)
                            .frame(width: 80, height: 80)
                            .foregroundColor(Color.green)
                            .overlay(
                                
                            Image(systemName: "questionmark.circle")
                                    .resizable()
                                    .frame(width: 40, height: 40)
                                    .offset(x: 0)
                                    .foregroundColor(.white)
                                
                            )
                        
                    }
                    .offset(x: 0.0)
                    
                    //Boton de información
                    Button(action: {
                        showModal.toggle()
                    }){
                        RoundedRectangle(cornerRadius: 100)
                            .shadow(color: .gray, radius: 4, x: 4, y: 4)
                            .frame(width: 80, height: 80)
                            .foregroundColor(Color.green)
                            .overlay(
                                
                                Image(systemName: "book")
                                    .resizable()
                                    .frame(width: 40, height: 40)
                                    .foregroundColor(.white)
                                
                            )
                        
                    }
                    .sheet(isPresented: $showModal) {
                        InformacionFiltro()
                    }
                    .offset(x: -210.0)
                }
                .offset(y: 30)
            }
        }
    }
}

#Preview {
    Menu()
}
