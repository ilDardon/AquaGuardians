//
//  Prueba2.swift
//  HakatonAxolots
//
//  Created by ADMIN UNACH on 06/03/24.
//

import SwiftUI

struct Prueba2: View {
    
    @State private var isLoading = true

    var body: some View {
        ZStack {
            // Contenido principal de tu vista
            Text("¡Hola, SwiftUI!")
                .foregroundColor(.white)
                .font(.largeTitle)
                .opacity(isLoading ? 0 : 1) // Oculta el contenido cuando isLoading es true

            // Pantalla de carga
            if isLoading {
                LoadingView()
            }
        }
        .background(
            LinearGradient(
                gradient: Gradient(colors: [Color.blue, Color.purple]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .edgesIgnoringSafeArea(.all)
        )
        .onAppear {
            // Simula un tiempo de carga, puedes reemplazar esto con el código real que necesitas para cargar datos
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                withAnimation {
                    isLoading = false
                }
            }
        }
    }
}

struct LoadingView: View {
    var body: some View {
        VStack {
            ProgressView() // Indicador de progreso (spinner)
                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                .scaleEffect(2) // Ajusta el tamaño del spinner

            Text("Cargando...")
                .foregroundColor(.white)
                .padding(.top, 8)
        }
    }
}



#Preview {
    Prueba2()
}
