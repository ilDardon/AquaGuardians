//
//  juegoCompletado.swift
//  AquaGuardians
//
//  Created by ADMIN UNACH on 07/03/24.
//

import SwiftUI

struct JuegoCompletado: View {
    
    @State private var isActiveInicio = false
    
    var body: some View {
        ZStack{
            Image("pantallaFinal")
                .resizable()
                .frame(width: 1210, height: 836)
                .overlay{
                    Button(action: {
                        isActiveInicio.toggle()
                    }){
                        Circle()
                            .shadow(color: .gray, radius: 3, x: 3, y: 3)
                            .frame(width: 80)
                            .foregroundColor(Color.orange)
                            .overlay(
                                Image(systemName: "rectangle.portrait.and.arrow.right")
                                    .resizable()
                                    .frame(width: 40, height: 40)
                                    .rotationEffect(.degrees(180))
                                
                                    .offset(x: -5)
                                    .foregroundColor(.white)
                            )
                    }.fullScreenCover(isPresented: $isActiveInicio){
                        Inicio()
                    }.position(x: 100 , y: 100)
                }
        }
    }
}

#Preview {
    JuegoCompletado()
}
