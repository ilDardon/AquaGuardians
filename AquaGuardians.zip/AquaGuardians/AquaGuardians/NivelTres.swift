//
//  NivelTres.swift
//  AquaGuardians
//
//  Created by ADMIN UNACH on 07/03/24.
//
import SwiftUI

import SwiftUI

struct NivelTres: View {
    @State private var nivelCompletado = false
    @State private var estrellas: Int = 0
    @State private var puntaje: Int = 0
    @State private var timer: Timer?
    @State private var tiempo = 0.0
    
    @State private var positions = [CGPoint(x: 60, y: 328), CGPoint(x: 60, y: 676), CGPoint(x: 60, y: 96), CGPoint(x: 60, y: 212),CGPoint(x: 60, y: 560), CGPoint(x: 60, y: 444)]
    @State private var isImageRemoved = [false, false, false, false, false, false]
    @State private var ocultarFondo = true
    
    @State private var isGlowing = false
    
    var body: some View {
        
        let minutos = Int(tiempo) / 60
        let segundos = Int(tiempo) % 60
        
        ZStack{
            
            LinearGradient(gradient: Gradient(colors: [Color(red: 0/255, green: 180/255, blue: 255/255),Color(red: 0/255, green: 180/255, blue: 0/255),Color(red: 155/255, green: 110/255, blue: 70/255), Color(red: 155/255, green: 110/255, blue: 70/255), Color(red: 76/255, green: 47/255, blue: 16/255)]), startPoint: .top, endPoint: .bottom)
            
            if !ocultarFondo{
                Image("fondoNivel3")
                    .resizable()
                    .scaledToFit()
                
                Image("cubo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 270)
                    .shadow(color: .yellow, radius: isGlowing ? 15 : 0)
                    .onAppear {
                        withAnimation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true)){
                            self.isGlowing.toggle()
                        }
                    }
                    .offset(x: 135, y: 175)
                    .onTapGesture {
                        withAnimation{
                            ocultarFondo.toggle()
                        }
                    }
            }
            
            if ocultarFondo{
                Image("tierra")
                    .resizable()
                    .scaledToFill()
                
                VStack(spacing: -5){
                    
                    RoundedRectangle(cornerRadius: 10.0)
                        .frame(width: 225,height: 200)
                        .foregroundStyle(.gray)
                        .shadow(radius: 10)
                        .offset(y:850)
                    
                    RoundedRectangle(cornerRadius: 25.0)
                        .foregroundStyle(.brown.opacity(0.8))
                        .frame(width: 510,height: 770)
                        .overlay{
                            VStack(spacing: 0){
                                
                                Image("f3filtro4")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 490)
                                    .opacity(isImageRemoved[5] ? 1 : 0)
                                    .overlay{
                                        RoundedRectangle(cornerRadius: 10.0)
                                            .stroke(.orange, lineWidth: 10)
                                            .frame(width:465, height: 110)
                                            .shadow(color: .orange,radius: 5)
                                            .animateVertically(endPosition: 2.5, duration: 0.5)
                                            .offset(y: 5)
                                            .opacity(isImageRemoved[0] && isImageRemoved[1] && isImageRemoved[2] && isImageRemoved[3] && isImageRemoved[4] && !isImageRemoved[5] ? 1 : 0)
                                            
                                    }
                                
                                Image("f3filtro4")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 490)
                                    .opacity(isImageRemoved[4] ? 1 : 0)
                                    .overlay{
                                        RoundedRectangle(cornerRadius: 10.0)
                                            .stroke(.orange, lineWidth: 10)
                                            .frame(width:465, height: 110)
                                            .shadow(color: .orange,radius: 5)
                                            .animateVertically(endPosition: 2.5, duration: 0.5)
                                            .offset(y: 5)
                                            .opacity(isImageRemoved[0] && isImageRemoved[1] && isImageRemoved[2] && isImageRemoved[3] && !isImageRemoved[4] ? 1 : 0)
                                            
                                    }
                                
                                Image("f3filtro3")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 490)
                                    .opacity(isImageRemoved[3] ? 1 : 0)
                                    .overlay{
                                        RoundedRectangle(cornerRadius: 10.0)
                                            .stroke(.orange, lineWidth: 10)
                                            .frame(width:465, height: 110)
                                            .shadow(color: .orange,radius: 5)
                                            .animateVertically(endPosition: 2.5, duration: 0.5)
                                            .offset(y: 5)
                                            .opacity(isImageRemoved[0] && isImageRemoved[1] && isImageRemoved[2] && !isImageRemoved[3] ? 1 : 0)
                                            
                                    }
                                    
                                
                                Image("f3filtro2")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 490)
                                    .opacity(isImageRemoved[2] ? 1 : 0)
                                    .overlay{
                                        RoundedRectangle(cornerRadius: 10.0)
                                            .stroke(.orange, lineWidth: 10)
                                            .frame(width:465)
                                            .shadow(color: .orange,radius: 5)
                                            .animateVertically(endPosition: 2.5, duration: 0.5)
                                            .offset(y: -5)
                                            .opacity(isImageRemoved[0] && isImageRemoved[1] && !isImageRemoved[2] ? 1 : 0)
                                    }
                                
                                Image("f3filtro1")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 490)
                                    .opacity(isImageRemoved[1] ? 1 : 0)
                                    .overlay{
                                        RoundedRectangle(cornerRadius: 10.0)
                                            .stroke(.orange, lineWidth: 10)
                                            .frame(width:465)
                                            .shadow(color: .orange,radius: 5)
                                            .animateVertically(endPosition: 2.5, duration: 0.5)
                                            .offset(y: -10)
                                            .opacity(isImageRemoved[0] && !isImageRemoved[1] ? 1 : 0)
                                    }
                                
                                Image("f3filtro0")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 490)
                                    .opacity(isImageRemoved[0] ? 1 : 0)
                                    .overlay{
                                        RoundedRectangle(cornerRadius: 10.0)
                                            .stroke(.orange, lineWidth: 10)
                                            .frame(width:465, height: 122.5)
                                            .shadow(color: .orange,radius: 5)
                                            .animateVertically(endPosition: 2.5, duration: 0.5)
                                            .offset(y: -15)
                                            .opacity(isImageRemoved[0] ? 0 : 1)
                                    }
                                
                            }.overlay{
                                RoundedRectangle(cornerRadius: 25.0)
                                    .stroke(.gray, lineWidth: 20)
                                    .frame(width: 500,height: 760)
                                    .overlay{
                                        Image("reflejo")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 650)
                                            .opacity(0.4)
                                            .rotationEffect(Angle(degrees: -25))
                                    }
                            }
                        }.shadow(radius: 10)
                        .offset(y: -100)
                }
                
                RoundedRectangle(cornerRadius: 50)
                    .shadow(color: .white, radius: 5)
                    .frame(width: 170, height: 70)
                    .foregroundColor(Color.orange)
                    .overlay(
                        Text(String(format: "%02d:%02d", minutos, segundos))
                            .font(.custom("Futura", size: 50))
                            .foregroundStyle(.white)
                    ).offset(x: 400, y: -320)
                    .animateVertically(endPosition: -5, duration: 2)
                    .onAppear {
                        tiempo = 0
                        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                            tiempo += 1
                        }
                    }
                    
                
                RoundedRectangle(cornerRadius: 25.0)
                    .foregroundStyle(.orange)
                    .frame(width: 125, height: 750)
                    .overlay{
                        RoundedRectangle(cornerRadius: 25.0)
                            .foregroundStyle(.white)
                            .frame(width: 115, height: 740)
                            .overlay{
                                ForEach(1..<7) { index in
                                    if !isImageRemoved[index-1] {
                                        Image("f3material\(index-1)")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 100, height: 100)
                                            .position(positions[index - 1])
                                            .gesture(
                                                DragGesture()
                                                    .onChanged { value in
                                                        // Actualizar la posición de la imagen mientras se arrastra
                                                        self.positions[index - 1] = value.location
                                                    }
                                                    .onEnded { value in
                                                        // Verificar si la imagen se está colocando en el orden correcto
                                                        if index - 1 == self.isImageRemoved.firstIndex(of: false) {
                                                            // Verificar si la imagen está en la posición correcta
                                                            if self.isImageInSpecificPosition(position: value.location) {
                                                                // Marcar la imagen como removida
                                                                withAnimation {
                                                                    self.isImageRemoved[index - 1] = true
                                                                }
                                                                // Comprobar si todas las imágenes están en orden
                                                                if self.isImageRemoved.allSatisfy({ $0 }) {
                                                                    // Marcar el nivel como completado
                                                                    withAnimation {
                                                                        self.nivelCompletado = true
                                                                        self.timer?.invalidate()
                                                                        self.puntaje = self.calcularPuntaje()
                                                                        // Calcular las estrellas basadas en el puntaje obtenido
                                                                        if self.puntaje >= 800 {
                                                                            self.estrellas = 3
                                                                        } else if self.puntaje >= 500 && self.puntaje < 800 {
                                                                            self.estrellas = 2
                                                                        } else if self.puntaje > 100 && self.puntaje < 500 {
                                                                            self.estrellas = 1
                                                                        } else {
                                                                            self.estrellas = 0
                                                                        }
                                                                        if self.puntaje < 0 {
                                                                            self.puntaje = 0
                                                                        }
                                                                    }
                                                                }
                                                            } else {
                                                                // Si la imagen está en el orden correcto pero no en su posición específica, restablecer su posición original
                                                                withAnimation {
                                                                    self.positions = [CGPoint(x: 60, y: 328), CGPoint(x: 60, y: 676), CGPoint(x: 60, y: 96), CGPoint(x: 60, y: 212),CGPoint(x: 60, y: 560), CGPoint(x: 60, y: 444)]
                                                                }
                                                            }
                                                        } else {
                                                            // Si la imagen no está en el orden correcto, restablecer su posición original
                                                            withAnimation {
                                                                self.positions = [CGPoint(x: 60, y: 328), CGPoint(x: 60, y: 676), CGPoint(x: 60, y: 96), CGPoint(x: 60, y: 212),CGPoint(x: 60, y: 560), CGPoint(x: 60, y: 444)]
                                                            }
                                                        }
                                                    }
                                            )
                                    }
                                }
                            }
                    }
                    .offset(x:-450)
            }
            
            if nivelCompletado {
                NivelCompletado(nivelCompletado: $nivelCompletado, estrellas: $estrellas, tiempo: $tiempo, puntaje: $puntaje, siguienteNivel: {
                    return JuegoCompletado()
                })
            }
            
        }.ignoresSafeArea()
    }
    
    // Function to check if an image is in a specific position
    func isImageInSpecificPosition(position: CGPoint) -> Bool {
        // Define your specific position here
        let specificPosition = CGPoint(x: 590, y: 400)
        let tolerance: CGFloat = 400
        return abs(position.x - specificPosition.x) < tolerance && abs(position.y - specificPosition.y) < tolerance
    }
    
    func calcularPuntaje() -> Int {
        let puntuacion = Int(1000 * exp(-0.005 * tiempo))
        return puntuacion
    }
    
}

#Preview {
    NivelTres()
}

