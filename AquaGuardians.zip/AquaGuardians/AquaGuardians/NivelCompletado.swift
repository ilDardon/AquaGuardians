//
//  NivelCompletado.swift
//  AquaGuardians
//
//  Created by ADMIN UNACH on 07/03/24.
//

import SwiftUI

struct NivelCompletado<NextView:View>: View {
    
    @Binding var nivelCompletado:Bool
    @Binding var estrellas:Int
    @Binding var tiempo:Double
    @Binding var puntaje:Int
    var siguienteNivel: () -> NextView
    @State private var menuActivo = false
    @State private var siguienteNivelActivo = false
    
    
    var body: some View {
        
        let minutos = Int(tiempo) / 60
        let segundos = Int(tiempo) % 60
        
        ZStack{
            
            if nivelCompletado{
                
                
                
                Color.black.opacity(0.5)
                
                Rectangle()
                    .frame(width: 450, height: 500)
                    .foregroundStyle(Color.white)
                    .clipShape(.buttonBorder)
                    .shadow(color: .white, radius: 5)
                    .overlay{
                        VStack(spacing: 20){
                            
                            Text(String(format: "%02d:%02d", minutos, segundos))
                                .font(.custom("Futura", size: 50))
                                .foregroundStyle(.black)
                            
                            HStack{
                                Image(systemName: "star.fill")
                                    .resizable()
                                    .foregroundStyle(estrellas != 0 ? .yellow : .white)
                                    .frame(width: 100, height: 100)
                                    .shadow(color: estrellas != 0 ? .yellow .opacity(0.8): .gray, radius: 10)
                                
                                Image(systemName: "star.fill")
                                    .resizable()
                                    .foregroundStyle(estrellas > 1 ? .yellow : .white)
                                    .frame(width: 100, height: 100)
                                    .shadow(color: estrellas > 1 ? .yellow .opacity(0.8): .gray, radius: 10)
                                
                                Image(systemName: "star.fill")
                                    .resizable()
                                    .foregroundStyle(estrellas == 3 ? .yellow : .white)
                                    .frame(width: 100, height: 100)
                                    .shadow(color: estrellas == 3 ? .yellow .opacity(0.8): .gray, radius: 10)
                            }
                            HStack{
                                Text("\(puntaje)")
                                    .font(.custom("Futura", size: 35))
                                    .foregroundStyle(.blue)
                                Text("PUNTOS")
                                    .font(.custom("Futura", size: 35))
                                    .foregroundStyle(.black)
                            }
                            
                            Text("NIVEL COMPLETADO")
                                .font(.custom("Futura", size: 35))
                                .foregroundStyle(.black)
                            
                            HStack{
                                
                                Button(action: {
                                    withAnimation(.spring(duration: 1)){
                                        menuActivo.toggle()
                                    }
                                }){
                                    Capsule()
                                        .frame(width: 200,height: 100)
                                        .foregroundStyle(.orange)
                                        .overlay{
                                            Image(systemName: "house.fill")
                                                .resizable()
                                                .foregroundStyle(.white)
                                                .frame(width: 50, height: 50)
                                        }
                                    
                                }.fullScreenCover(isPresented: $menuActivo){
                                    Menu()
                                }
                                
                                Button(action: {
                                    withAnimation(.spring(duration: 1)){
                                        siguienteNivelActivo.toggle()
                                    }
                                }){
                                    Capsule()
                                        .frame(width: 200,height: 100)
                                        .foregroundStyle(.orange)
                                        .overlay{
                                            Image(systemName: "arrowshape.right.fill")
                                                .resizable()
                                                .foregroundStyle(.white)
                                                .frame(width: 75, height: 50)
                                        }
                                }
                            }
                        }
                    }
            }
            
            if siguienteNivelActivo{
                siguienteNivel()
            }
            
        }.ignoresSafeArea()
    }
}

#Preview {
    NivelCompletado(nivelCompletado:.constant(true) , estrellas: .constant(3), tiempo: .constant(1000), puntaje: .constant(1000), siguienteNivel: {
        return NivelDos()
    })
}

