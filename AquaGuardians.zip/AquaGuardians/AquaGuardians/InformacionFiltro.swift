//
//  InformacionFIltro.swift
//  HakatonAxolots
//
//  Created by ADMIN UNACH on 06/03/24.
//

import SwiftUI

struct InformacionFiltro: View {
    
    @State private var isImage1Visible = false
    @State private var isImage2Visible = false
    @State private var isImage3Visible = false
    
    var body: some View {
        
        ZStack {
             
            Color.white
            
            Image("fondoGuiaArena")
                .resizable()
                .frame(width: 720, height: 90)
                .offset(y: -320)
            
            Image("fondoGuiaViruta")
                .resizable()
                .frame(width: 725, height: 90)
                .offset(y: 320)
            
            RoundedRectangle(cornerRadius: 5.0)
                .stroke(lineWidth: 10.0)
                .foregroundStyle(.white)
                .frame(width: 710, height: 725)
            
            if isImage1Visible {
                
                RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                    .foregroundStyle(.white)
                    .frame(width: 400, height: 70)
                    .shadow(color: .gray, radius: 5, x: 10, y: 10)
                    .overlay{
                        Text("Guía Rapida")
                            .font(Font.custom("Arial Rounded MT Bold", size: 40))
                            .foregroundColor(.black)
                    }
                    .offset(x: 0.0, y: -280)
                
                HStack{
                    
                    if isImage2Visible {
                        Image("ajoloteLentes")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .black, radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                            .frame(width: 200, height: 400)
                            .offset(x: 0.0, y: -30)
                            .animateVertically(endPosition: 30.0, duration: 1.0)
                    }
                    
                    if isImage3Visible{
                        Images(images: ["image1", "image2", "image3", "image4"])
                            .frame(width: 400, height: 400)
                    }
                }
                .padding(.top, 20)

            }
            
        }
        .onAppear {
            // Puedes agregar algún retraso (con DispatchQueue) si quieres un intervalo de tiempo entre cada imagen
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                withAnimation {
                    isImage1Visible = true
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                withAnimation {
                    isImage2Visible = true
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                withAnimation {
                    isImage3Visible = true
                }
            }
                        
        }

    }
    
}

#Preview {
    InformacionFiltro()
}


