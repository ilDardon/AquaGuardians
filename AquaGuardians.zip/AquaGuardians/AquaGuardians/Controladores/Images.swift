//
//  Images.swift
//  AquaGuardians
//
//  Created by ADMIN UNACH on 07/03/24.
//

import SwiftUI


struct Images: View {
    
    let images: [String] // Rutas de las imágenes

    var body: some View {
        TabView {
            ForEach(images, id: \.self) { imageName in
                Image(imageName)
                    .resizable()
//                    .scaledToFit()
            }
        }
        .tabViewStyle(PageTabViewStyle()) // Estilo de pestañas
        .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always)) // Mostrar índices
    }
}
