//
//  VerticalAnimation.swift
//  AquaGuardians
//
//  Created by ADMIN UNACH on 07/03/24.
//
import SwiftUI

struct VerticalAnimation : ViewModifier{
    
    @State private var startPosition: CGFloat = 0
    let endPosition: CGFloat
    let duration: TimeInterval
    
    func body(content: Content) -> some View{
        content
            .offset(y: startPosition)
            .onAppear{
                withAnimation(Animation.easeInOut(duration: duration).repeatForever(autoreverses: true)){
                    self.startPosition = self.endPosition
                }
            }
    }
}

extension View{
    func animateVertically(endPosition: CGFloat, duration: TimeInterval) -> some View{
        self.modifier(VerticalAnimation( endPosition: endPosition, duration: duration))
    }
}
