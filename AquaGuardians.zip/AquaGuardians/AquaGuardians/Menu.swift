//
//  Menu.swift
//  AquaGuardians
//
//  Created by ADMIN UNACH on 07/03/24.
//

import SwiftUI

struct Menu: View {

    @State private var showModal = false
    @State private var isActiveInicio = false
    @State private var isActiveTutorial = false
    
    @State private var isActiveNivelUno = false
    @State private var isActiveNivelDos = false
    @State private var isActiveNivelTres = false
    
    var body: some View {
        
        ZStack{
            
            Image("mapaFlotante")
                .resizable()
                .frame(width: 1210, height: 836)
                .offset(x: 8, y: -7)
            
            Button(action: {
                isActiveNivelUno.toggle()
            }){
                Image("casaFlotante")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 135)
                    .animateVertically(endPosition: -20.0, duration: 1)
                    .shadow(color: Color.white, radius: 5)

            }.fullScreenCover(isPresented: $isActiveNivelUno){
                NivelUno()
            }
            .offset(x: -490, y: 130)
            
            Button(action: {
                isActiveNivelDos.toggle()
            }){
                Image("casitas")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 220)
                    .animateVertically(endPosition: -20, duration: 1)
                    .shadow(color: Color.white, radius: 5)

            }.fullScreenCover(isPresented: $isActiveNivelDos){
                NivelDos()
            }
            .offset(x: -205, y: -180)

            Button(action: {
                isActiveNivelTres.toggle()
            }){
                Image("vaca")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150)
                    .animateVertically(endPosition: -20.0, duration: 1)
                    .shadow(color: Color.white, radius: 5)

            }.fullScreenCover(isPresented: $isActiveNivelTres){
                NivelTres()
            }
            .offset(x: 160, y: -80)
            
            
            RoundedRectangle(cornerRadius: 25.0)
                .stroke(.gray, lineWidth: 10)
                .frame(width: 330, height: 110)
                .shadow(color: .white, radius: 5)
                .overlay{
                    RoundedRectangle(cornerRadius: 25.0)
                        .foregroundStyle(.white)
                        .frame(width: 330, height: 110)
                        .overlay{
                            HStack(spacing: 25){
                    
                                Button(action: {
                                    isActiveInicio.toggle()
                                }){
                                    Circle()
                                        .shadow(color: .gray, radius: 3, x: 3, y: 3)
                                        .frame(width: 80)
                                        .foregroundColor(Color.green)
                                        .overlay(
                                            Image(systemName: "rectangle.portrait.and.arrow.right")
                                                .resizable()
                                                .frame(width: 40, height: 40)
                                                .rotationEffect(.degrees(180))

                                                .offset(x: -5)
                                                .foregroundColor(.white)
                                        )
                                }.fullScreenCover(isPresented: $isActiveInicio){
                                    Inicio()
                                }
                                
                                Button(action: {
                                    isActiveTutorial.toggle()
                                }){
                                    Circle()
                                        .shadow(color: .gray, radius: 3, x: 3, y: 3)
                                        .frame(width: 80)
                                        .foregroundColor(Color.green)
                                        .overlay(
                                        Image(systemName: "questionmark.circle")
                                                .resizable()
                                                .frame(width: 40, height: 40)
                                                .offset(x: 0)
                                                .foregroundColor(.white)
                                        )
                                }.sheet(isPresented: $isActiveTutorial) {
                                    ModoJuego()
                                }
                                
                                Button(action: {
                                    showModal.toggle()
                                }){
                                    Circle()
                                        .shadow(color: .gray, radius: 3, x: 3, y: 3)
                                        .frame(width: 80)
                                        .foregroundColor(Color.green)
                                        .overlay(
                                            Image(systemName: "book")
                                                .resizable()
                                                .frame(width: 40, height: 40)
                                                .foregroundColor(.white)
                                        )
                                }
                                .sheet(isPresented: $showModal) {
                                    InformacionFiltro()
                                }
                            }.animateVertically(endPosition: -5, duration: 3)
                        }
                }.offset(y: 300)
        }.ignoresSafeArea()
    }
}

#Preview {
    Menu()
}
