//
//  AquaGuardiansApp.swift
//  AquaGuardians
//
//  Created by ADMIN UNACH on 07/03/24.
//

import SwiftUI

@main
struct AquaGuardiansApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
