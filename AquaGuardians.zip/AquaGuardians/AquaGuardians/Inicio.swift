//
//  Inicio.swift
//  AquaGuardians
//
//  Created by ADMIN UNACH on 07/03/24.
//

import SwiftUI

struct Inicio: View {

    @State private var isActiveMenu = false
   
    var body: some View {
        
        ZStack {
            
            Image("rio")
                .resizable()
                .frame(width: 1229, height: 1028)
            
            VStack{
                
                Image("ajolote")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 390)
                    .shadow(color : .black, radius: 5)
                    .offset(x: -300, y: 280)
                    .animateVertically(endPosition: 20.0, duration: 0.4)
                
                Button(action: {
                    isActiveMenu.toggle()
                }){
                    Circle()
                        .foregroundStyle(.orange)
                        .frame(width: 300)
                        .shadow(color : Color.white, radius: 5)
                        .overlay{
                            Image(systemName: "arrowtriangle.right.circle.fill")
                                .resizable()
                                .frame(width: 250, height: 250)
                                .foregroundStyle(.white)
                                .shadow(color: .white, radius: 5)
                        }
                        .animateVertically(endPosition: 5.0, duration: 1)
                }
                .offset(x: 300, y: -200)
                .fullScreenCover(isPresented: $isActiveMenu){
                    Menu()
                }
                
                RoundedRectangle(cornerRadius: 25.0)
                    .stroke(.white, lineWidth: 10)
                    .frame(width: 780, height: 110)
                    .shadow(color: .white, radius: 5)
                    .overlay{
                        RoundedRectangle(cornerRadius: 25.0)
                            .frame(width: 780, height: 110)
                            .foregroundStyle(.orange)
                            .overlay{
                                HStack(spacing: 0){
                                    Text("A")
                                        .foregroundColor(.blue)
                                        .font(.custom("Arial Rounded MT Bold", size: 80))
                                        .shadow(color: .white, radius: 5)
                                    
                                    Image(systemName: "leaf")
                                        .resizable()
                                        .foregroundStyle(.blue)
                                        .shadow(color: .white, radius: 5)
                                        .scaledToFit()
                                        .frame(width: 80)
                                        .rotationEffect(.degrees(20))
                                    
                                    Text("UA")
                                        .foregroundColor(.blue)
                                        .font(.custom("Arial Rounded MT Bold", size: 80))
                                        .shadow(color: .white, radius: 5)
                                
                                    /*
                                    Text("GUARDIANS")
                                        .foregroundColor(.white)
                                        .font(Font.custom("Futura", size: 80))
                                        .shadow(color: .white, radius: 5)
                                    */
                                    Text("GUARDIANS")
                                        .font(Font.custom("Futura", size: 80))
                                        .foregroundColor(Color.gray)
                                        .shadow(color: Color.white.opacity(0.8), radius: 2, x: -2, y: -2)
                                        .shadow(color: Color.black.opacity(0.6), radius: 2, x: 2, y: 2)
                                        .overlay(
                                            LinearGradient(gradient: Gradient(colors: [Color.white.opacity(0.8), Color.gray]), startPoint: .top, endPoint: .bottom)
                                                .mask(Text("GUARDIANS")
                                                    .font(Font.custom("Futura", size: 80))
                                                )
                                        ).shadow(color: .white, radius: 3)
                                    
                                    
                                    
                                }
                            }
                    }.offset(y: -700)
                
            }
        }
    }
}

#Preview {
    Inicio()
}
