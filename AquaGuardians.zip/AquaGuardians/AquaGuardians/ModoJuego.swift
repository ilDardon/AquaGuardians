//
//  ModoJuego.swift
//  AquaGuardians
//
//  Created by ADMIN UNACH on 07/03/24.
//
import SwiftUI

struct ModoJuego: View {
    
    var body: some View {
        
        ZStack{
            
            Color.white
            
            Image("fondoTutorialGrava")
                .resizable()
                .frame(width: 725, height: 120)
                .offset(y: -310)
            
            Image("fondoTutorialGravilla")
                .resizable()
                .frame(width: 725, height: 120)
                .offset(y: 310)
            
            RoundedRectangle(cornerRadius: 5.0)
                .stroke(lineWidth: 10.0)
                .foregroundStyle(.white)
                .frame(width: 710, height: 725)
            
            HStack(spacing: 50){
                

                        VStack(spacing: 50){
                            
                            RoundedRectangle(cornerRadius: 50.0)
                                .foregroundStyle(.brown)
                                .frame(width: 70, height: 100)
                                .overlay{
                                    Image(systemName: "book.pages")
                                        .resizable()
                                        .frame(width: 50, height: 50)
                                }
                            
                            RoundedRectangle(cornerRadius: 50.0)
                                .foregroundStyle(.brown)
                                .frame(width: 70, height: 100)
                                .overlay{
                                    Image(systemName: "hammer")
                                        .resizable()
                                        .frame(width: 50, height: 50)
                                }
                            
                            RoundedRectangle(cornerRadius: 50.0)
                                .foregroundStyle(.brown)
                                .frame(width: 70, height: 100)
                                .overlay{
                                    Image(systemName: "checkmark.circle")
                                        .resizable()
                                        .frame(width: 50, height: 50)
                                }
                            
                        }
                        .foregroundStyle(.white)
                
                VStack (spacing: 60){
                    Text("Consulta la guía sobre Biofiltros para comenzar tu aventura como AquaGuardian")
                                
                    Text("Crea un Biofiltro para cada reto y aprende junto a Axolotl")
                        .padding(.trailing, 140)
                                
                    Text("Ayuda a restaurar un río y transformate en AquaGuardian Principiante")
                                    .padding(.trailing, 70)
                }
                .foregroundStyle(.black)
                .frame(width: 400, height: 700)
                .font(Font.custom("Arial Rounded MT Bold", size: 25))

            }
        }
        
    }
    
}

#Preview {
    ModoJuego()
}
